
public class Main1 {

    
    public static void main(String[] args) {
      SeleccionFutbol delbosque= new Entrenador(1, "Vicente", "Del Bosque", 60, 28489 );
      SeleccionFutbol iniesta= new Futbolista(2, "Andres", "Iniesta", 29, 6, "Interior Derecho");
      SeleccionFutbol raulMartinez= new Masajista(3, "Raul", "Martinez", 41, "Licenciado en Fisioterapia", 18);
      
//CONCENTRACION
      System.out.print(delbosque.getNombre()+""+delbosque.getApellidos()+"->");delbosque.concentrarse();
     System.out.print(iniesta.getNombre()+""+iniesta.getApellidos()+"->");iniesta.concentrarse();
     System.out.print(raulMartinez.getNombre()+""+raulMartinez.getApellidos()+"->");raulMartinez.concentrarse();
     
     //VIAJAR
      System.out.print(delbosque.getNombre()+""+delbosque.getApellidos()+"->");delbosque.viajar();
     System.out.print(iniesta.getNombre()+""+iniesta.getApellidos()+"->");iniesta.viajar();
     System.out.print(raulMartinez.getNombre()+""+raulMartinez.getApellidos()+"->");raulMartinez.viajar();
     
     //ENTRENAMIENTO
     System.out.println("\nPartido de Futbol: Todos los integrantes tienen su funcion en un entrenamiento(Especializacion");
      System.out.print(delbosque.getNombre()+""+delbosque.getApellidos()+"->");delbosque.entrenar();
     System.out.print(iniesta.getNombre()+""+iniesta.getApellidos()+"->");iniesta.entrenar();
     System.out.print(raulMartinez.getNombre()+""+raulMartinez.getApellidos()+"->");raulMartinez.entrenar();
     
     //PARTIDO DE FUTBOL
      System.out.println("\nPartido de Futbol: Todos los integrantes tienen su funcion en un partido(Especializacion");
      System.out.print(delbosque.getNombre()+""+delbosque.getApellidos()+"->");delbosque.jugarpartido();
     System.out.print(iniesta.getNombre()+""+iniesta.getApellidos()+"->");iniesta.jugarpartido();
     System.out.print(raulMartinez.getNombre()+""+raulMartinez.getApellidos()+"->");raulMartinez.jugarpartido();
      
     //PLANIFICAR ENTRENAMIENTO
      System.out.println("\nPlanificar Entrenamiento: Solo el entrenador tiene el metodo para planificar un entrenamiento");
      System.out.print(delbosque.getNombre()+""+delbosque.getApellidos()+"->");
      ((Entrenador)delbosque).planificarEntrenamiento();
      
      //ENTREVISTA
       System.out.println("\nEntrevista: Solos el futbolista tiene el metodo para dar una entrevista:");
       System.out.print(iniesta.nombre +""+iniesta.getApellidos()+"->");
       ((Futbolista) iniesta).entrevista();
       
       //MASAJE
        System.out.println("\nMasaje: Solo el masajista tiene el metodo para dar un masaje:");
        System.out.print(raulMartinez.getNombre()+""+raulMartinez.getApellidos()+"->");
        ((Masajista) raulMartinez).darMasaje();
    }
    
    
}
