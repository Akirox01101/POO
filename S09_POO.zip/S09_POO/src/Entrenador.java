
public class Entrenador extends SeleccionFutbol {
    private int idFedereacion;

    public Entrenador() {
        super();
    }

    public Entrenador(int id, String nombre, String apellidos,int edad, int idFedereacion) {
        super(id, nombre, apellidos, edad);
        this.idFedereacion = idFedereacion;
    }

    public int getIdFedereacion() {
        return idFedereacion;
    }

    public void setIdFedereacion(int idFedereacion) {
        this.idFedereacion = idFedereacion;
    }
    
    @Override
    public void entrenar(){
        System.out.println("Dirige un entrenamiento (Clase Entrenador)");
    }
    @Override
    public void jugarpartido(){
        System.out.println("Dirige un partido (Clase Entrenador)");
    }
    public void planificarEntrenamiento(){
        System.out.println("Planificar un entrenamiento");
    }
}
